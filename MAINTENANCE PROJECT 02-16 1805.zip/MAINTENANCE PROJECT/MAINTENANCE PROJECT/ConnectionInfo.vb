﻿Public Class DBConnectionInfo
    Private Const username As String = "PROJECTS1718"
    Private Const password As String = "ND24rp$"
    Private Const DBName As String = "PROJECTS1718"

    Private ConnString As String = "Provider=SQLNCLI11;Server=msenterprise.waltoncollege.uark.edu;Database=" & DBName & ";UID=" & username & ";PWD=" & password & ";"

    Public Function GetConnString() As String
        Return ConnString
    End Function
End Class

