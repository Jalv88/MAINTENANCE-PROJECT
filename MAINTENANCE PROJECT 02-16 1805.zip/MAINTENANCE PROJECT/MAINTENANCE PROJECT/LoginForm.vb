﻿Public Class LoginForm

   
    Private Sub Clearbutton_Click(sender As Object, e As EventArgs) Handles Clearbutton.Click
        'this clears the text box fields
        UserNameTextBox.Text = ""
        PasswordTextBox.Text = ""
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        'this closes the program
        Me.Close()
    End Sub

    Private Sub Loginbutton_Click(sender As Object, e As EventArgs) Handles Loginbutton.Click

        If UserNameTextBox.Text = "admin" And
         PasswordTextBox.Text = "password" Then
            MessageBox.Show("You are now logged in")
        Else : MessageBox.Show("Invalid Login Credentials")
        End If

    End Sub
End Class
