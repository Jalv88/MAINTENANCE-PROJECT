﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentRecords
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ExitButton1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.StudentIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiddleInitialDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SSNDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOBDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EthnicityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GenderDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CitizenshipDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ZipDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PrimaryContactNumDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MajorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CumulativeGPADataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.L60GPADataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GMATDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GREDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EssayDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RecommendationLetterDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.YearsOfWorkXPDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApplicationCompleteDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.VplusQDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentInfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSet1 = New MAINTENANCE_PROJECT.DataSet1()
        Me.NewSearch = New System.Windows.Forms.Button()
        Me.SearchButton = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.MajorTB = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GMATTB = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.CGPATB = New System.Windows.Forms.TextBox()
        Me.VplusQTB = New System.Windows.Forms.TextBox()
        Me.L60GPATB = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.AppCompTB = New System.Windows.Forms.TextBox()
        Me.WorkXPTB = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.PhoneTB = New System.Windows.Forms.TextBox()
        Me.CountryTB = New System.Windows.Forms.TextBox()
        Me.ZIPTB = New System.Windows.Forms.TextBox()
        Me.StateTB = New System.Windows.Forms.TextBox()
        Me.CityTB = New System.Windows.Forms.TextBox()
        Me.AddressTB = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.LastNameTB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FirstNameTB = New System.Windows.Forms.TextBox()
        Me.DOBTB = New System.Windows.Forms.TextBox()
        Me.MiddleNameTB = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SSNTB = New System.Windows.Forms.TextBox()
        Me.StudentIDTB = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GenderTExtBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CitizenTextBox = New System.Windows.Forms.TextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.StudentInfoTableAdapter = New MAINTENANCE_PROJECT.DataSet1TableAdapters.StudentInfoTableAdapter()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentInfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1047, 412)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Admission Request"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.ExitButton1)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Controls.Add(Me.NewSearch)
        Me.TabPage1.Controls.Add(Me.SearchButton)
        Me.TabPage1.Controls.Add(Me.GroupBox6)
        Me.TabPage1.Controls.Add(Me.GroupBox5)
        Me.TabPage1.Controls.Add(Me.GroupBox4)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1047, 412)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Student Information"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ExitButton1
        '
        Me.ExitButton1.Location = New System.Drawing.Point(755, 363)
        Me.ExitButton1.Name = "ExitButton1"
        Me.ExitButton1.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton1.TabIndex = 31
        Me.ExitButton1.Text = "Exit"
        Me.ExitButton1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudentIDDataGridViewTextBoxColumn, Me.LastNameDataGridViewTextBoxColumn, Me.MiddleInitialDataGridViewTextBoxColumn, Me.FirstNameDataGridViewTextBoxColumn, Me.EmailDataGridViewTextBoxColumn, Me.SSNDataGridViewTextBoxColumn, Me.DOBDataGridViewTextBoxColumn, Me.EthnicityDataGridViewTextBoxColumn, Me.GenderDataGridViewTextBoxColumn, Me.CitizenshipDataGridViewTextBoxColumn, Me.StreetDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.StateDataGridViewTextBoxColumn, Me.ZipDataGridViewTextBoxColumn, Me.CountryDataGridViewTextBoxColumn, Me.PrimaryContactNumDataGridViewTextBoxColumn, Me.MajorDataGridViewTextBoxColumn, Me.CumulativeGPADataGridViewTextBoxColumn, Me.L60GPADataGridViewTextBoxColumn, Me.GMATDataGridViewTextBoxColumn, Me.GREDataGridViewTextBoxColumn, Me.EssayDataGridViewTextBoxColumn, Me.RecommendationLetterDataGridViewTextBoxColumn, Me.YearsOfWorkXPDataGridViewTextBoxColumn, Me.ApplicationCompleteDataGridViewCheckBoxColumn, Me.VplusQDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.StudentInfoBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(529, 165)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(493, 192)
        Me.DataGridView1.TabIndex = 30
        '
        'StudentIDDataGridViewTextBoxColumn
        '
        Me.StudentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID"
        Me.StudentIDDataGridViewTextBoxColumn.HeaderText = "StudentID"
        Me.StudentIDDataGridViewTextBoxColumn.Name = "StudentIDDataGridViewTextBoxColumn"
        '
        'LastNameDataGridViewTextBoxColumn
        '
        Me.LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.Name = "LastNameDataGridViewTextBoxColumn"
        '
        'MiddleInitialDataGridViewTextBoxColumn
        '
        Me.MiddleInitialDataGridViewTextBoxColumn.DataPropertyName = "MiddleInitial"
        Me.MiddleInitialDataGridViewTextBoxColumn.HeaderText = "MiddleInitial"
        Me.MiddleInitialDataGridViewTextBoxColumn.Name = "MiddleInitialDataGridViewTextBoxColumn"
        '
        'FirstNameDataGridViewTextBoxColumn
        '
        Me.FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.Name = "FirstNameDataGridViewTextBoxColumn"
        '
        'EmailDataGridViewTextBoxColumn
        '
        Me.EmailDataGridViewTextBoxColumn.DataPropertyName = "Email"
        Me.EmailDataGridViewTextBoxColumn.HeaderText = "Email"
        Me.EmailDataGridViewTextBoxColumn.Name = "EmailDataGridViewTextBoxColumn"
        '
        'SSNDataGridViewTextBoxColumn
        '
        Me.SSNDataGridViewTextBoxColumn.DataPropertyName = "SSN"
        Me.SSNDataGridViewTextBoxColumn.HeaderText = "SSN"
        Me.SSNDataGridViewTextBoxColumn.Name = "SSNDataGridViewTextBoxColumn"
        '
        'DOBDataGridViewTextBoxColumn
        '
        Me.DOBDataGridViewTextBoxColumn.DataPropertyName = "DOB"
        Me.DOBDataGridViewTextBoxColumn.HeaderText = "DOB"
        Me.DOBDataGridViewTextBoxColumn.Name = "DOBDataGridViewTextBoxColumn"
        '
        'EthnicityDataGridViewTextBoxColumn
        '
        Me.EthnicityDataGridViewTextBoxColumn.DataPropertyName = "Ethnicity"
        Me.EthnicityDataGridViewTextBoxColumn.HeaderText = "Ethnicity"
        Me.EthnicityDataGridViewTextBoxColumn.Name = "EthnicityDataGridViewTextBoxColumn"
        '
        'GenderDataGridViewTextBoxColumn
        '
        Me.GenderDataGridViewTextBoxColumn.DataPropertyName = "Gender"
        Me.GenderDataGridViewTextBoxColumn.HeaderText = "Gender"
        Me.GenderDataGridViewTextBoxColumn.Name = "GenderDataGridViewTextBoxColumn"
        '
        'CitizenshipDataGridViewTextBoxColumn
        '
        Me.CitizenshipDataGridViewTextBoxColumn.DataPropertyName = "Citizenship"
        Me.CitizenshipDataGridViewTextBoxColumn.HeaderText = "Citizenship"
        Me.CitizenshipDataGridViewTextBoxColumn.Name = "CitizenshipDataGridViewTextBoxColumn"
        '
        'StreetDataGridViewTextBoxColumn
        '
        Me.StreetDataGridViewTextBoxColumn.DataPropertyName = "Street"
        Me.StreetDataGridViewTextBoxColumn.HeaderText = "Street"
        Me.StreetDataGridViewTextBoxColumn.Name = "StreetDataGridViewTextBoxColumn"
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "City"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "City"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        '
        'StateDataGridViewTextBoxColumn
        '
        Me.StateDataGridViewTextBoxColumn.DataPropertyName = "State"
        Me.StateDataGridViewTextBoxColumn.HeaderText = "State"
        Me.StateDataGridViewTextBoxColumn.Name = "StateDataGridViewTextBoxColumn"
        '
        'ZipDataGridViewTextBoxColumn
        '
        Me.ZipDataGridViewTextBoxColumn.DataPropertyName = "Zip"
        Me.ZipDataGridViewTextBoxColumn.HeaderText = "Zip"
        Me.ZipDataGridViewTextBoxColumn.Name = "ZipDataGridViewTextBoxColumn"
        '
        'CountryDataGridViewTextBoxColumn
        '
        Me.CountryDataGridViewTextBoxColumn.DataPropertyName = "Country"
        Me.CountryDataGridViewTextBoxColumn.HeaderText = "Country"
        Me.CountryDataGridViewTextBoxColumn.Name = "CountryDataGridViewTextBoxColumn"
        '
        'PrimaryContactNumDataGridViewTextBoxColumn
        '
        Me.PrimaryContactNumDataGridViewTextBoxColumn.DataPropertyName = "PrimaryContactNum"
        Me.PrimaryContactNumDataGridViewTextBoxColumn.HeaderText = "PrimaryContactNum"
        Me.PrimaryContactNumDataGridViewTextBoxColumn.Name = "PrimaryContactNumDataGridViewTextBoxColumn"
        '
        'MajorDataGridViewTextBoxColumn
        '
        Me.MajorDataGridViewTextBoxColumn.DataPropertyName = "Major"
        Me.MajorDataGridViewTextBoxColumn.HeaderText = "Major"
        Me.MajorDataGridViewTextBoxColumn.Name = "MajorDataGridViewTextBoxColumn"
        '
        'CumulativeGPADataGridViewTextBoxColumn
        '
        Me.CumulativeGPADataGridViewTextBoxColumn.DataPropertyName = "CumulativeGPA"
        Me.CumulativeGPADataGridViewTextBoxColumn.HeaderText = "CumulativeGPA"
        Me.CumulativeGPADataGridViewTextBoxColumn.Name = "CumulativeGPADataGridViewTextBoxColumn"
        '
        'L60GPADataGridViewTextBoxColumn
        '
        Me.L60GPADataGridViewTextBoxColumn.DataPropertyName = "L60GPA"
        Me.L60GPADataGridViewTextBoxColumn.HeaderText = "L60GPA"
        Me.L60GPADataGridViewTextBoxColumn.Name = "L60GPADataGridViewTextBoxColumn"
        '
        'GMATDataGridViewTextBoxColumn
        '
        Me.GMATDataGridViewTextBoxColumn.DataPropertyName = "GMAT"
        Me.GMATDataGridViewTextBoxColumn.HeaderText = "GMAT"
        Me.GMATDataGridViewTextBoxColumn.Name = "GMATDataGridViewTextBoxColumn"
        '
        'GREDataGridViewTextBoxColumn
        '
        Me.GREDataGridViewTextBoxColumn.DataPropertyName = "GRE"
        Me.GREDataGridViewTextBoxColumn.HeaderText = "GRE"
        Me.GREDataGridViewTextBoxColumn.Name = "GREDataGridViewTextBoxColumn"
        '
        'EssayDataGridViewTextBoxColumn
        '
        Me.EssayDataGridViewTextBoxColumn.DataPropertyName = "Essay"
        Me.EssayDataGridViewTextBoxColumn.HeaderText = "Essay"
        Me.EssayDataGridViewTextBoxColumn.Name = "EssayDataGridViewTextBoxColumn"
        '
        'RecommendationLetterDataGridViewTextBoxColumn
        '
        Me.RecommendationLetterDataGridViewTextBoxColumn.DataPropertyName = "RecommendationLetter"
        Me.RecommendationLetterDataGridViewTextBoxColumn.HeaderText = "RecommendationLetter"
        Me.RecommendationLetterDataGridViewTextBoxColumn.Name = "RecommendationLetterDataGridViewTextBoxColumn"
        '
        'YearsOfWorkXPDataGridViewTextBoxColumn
        '
        Me.YearsOfWorkXPDataGridViewTextBoxColumn.DataPropertyName = "YearsOfWorkXP"
        Me.YearsOfWorkXPDataGridViewTextBoxColumn.HeaderText = "YearsOfWorkXP"
        Me.YearsOfWorkXPDataGridViewTextBoxColumn.Name = "YearsOfWorkXPDataGridViewTextBoxColumn"
        '
        'ApplicationCompleteDataGridViewCheckBoxColumn
        '
        Me.ApplicationCompleteDataGridViewCheckBoxColumn.DataPropertyName = "ApplicationComplete"
        Me.ApplicationCompleteDataGridViewCheckBoxColumn.HeaderText = "ApplicationComplete"
        Me.ApplicationCompleteDataGridViewCheckBoxColumn.Name = "ApplicationCompleteDataGridViewCheckBoxColumn"
        '
        'VplusQDataGridViewTextBoxColumn
        '
        Me.VplusQDataGridViewTextBoxColumn.DataPropertyName = "VplusQ"
        Me.VplusQDataGridViewTextBoxColumn.HeaderText = "VplusQ"
        Me.VplusQDataGridViewTextBoxColumn.Name = "VplusQDataGridViewTextBoxColumn"
        '
        'StudentInfoBindingSource
        '
        Me.StudentInfoBindingSource.DataMember = "StudentInfo"
        Me.StudentInfoBindingSource.DataSource = Me.DataSet1
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "DataSet1"
        Me.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'NewSearch
        '
        Me.NewSearch.Location = New System.Drawing.Point(654, 363)
        Me.NewSearch.Name = "NewSearch"
        Me.NewSearch.Size = New System.Drawing.Size(75, 23)
        Me.NewSearch.TabIndex = 29
        Me.NewSearch.Text = "New Search"
        Me.NewSearch.UseVisualStyleBackColor = True
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(548, 363)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 28
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.MajorTB)
        Me.GroupBox6.Controls.Add(Me.Label14)
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Controls.Add(Me.GMATTB)
        Me.GroupBox6.Controls.Add(Me.Label16)
        Me.GroupBox6.Controls.Add(Me.Label17)
        Me.GroupBox6.Controls.Add(Me.CGPATB)
        Me.GroupBox6.Controls.Add(Me.VplusQTB)
        Me.GroupBox6.Controls.Add(Me.L60GPATB)
        Me.GroupBox6.Controls.Add(Me.Label18)
        Me.GroupBox6.Controls.Add(Me.Label19)
        Me.GroupBox6.Controls.Add(Me.AppCompTB)
        Me.GroupBox6.Controls.Add(Me.WorkXPTB)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Location = New System.Drawing.Point(529, 28)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(493, 130)
        Me.GroupBox6.TabIndex = 27
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Student Information"
        '
        'MajorTB
        '
        Me.MajorTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Major", True))
        Me.MajorTB.Location = New System.Drawing.Point(78, 19)
        Me.MajorTB.Name = "MajorTB"
        Me.MajorTB.Size = New System.Drawing.Size(140, 20)
        Me.MajorTB.TabIndex = 6
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(8, 53)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Cumulative GPA"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(8, 23)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(33, 13)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Major"
        '
        'GMATTB
        '
        Me.GMATTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "GMAT", True))
        Me.GMATTB.Location = New System.Drawing.Point(129, 102)
        Me.GMATTB.Name = "GMATTB"
        Me.GMATTB.Size = New System.Drawing.Size(89, 20)
        Me.GMATTB.TabIndex = 16
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(8, 80)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(47, 13)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "L60GPA"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(8, 106)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 13)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "GMAT"
        '
        'CGPATB
        '
        Me.CGPATB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "CumulativeGPA", True))
        Me.CGPATB.Location = New System.Drawing.Point(129, 49)
        Me.CGPATB.Name = "CGPATB"
        Me.CGPATB.Size = New System.Drawing.Size(89, 20)
        Me.CGPATB.TabIndex = 5
        '
        'VplusQTB
        '
        Me.VplusQTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "VplusQ", True))
        Me.VplusQTB.Location = New System.Drawing.Point(367, 80)
        Me.VplusQTB.Name = "VplusQTB"
        Me.VplusQTB.Size = New System.Drawing.Size(65, 20)
        Me.VplusQTB.TabIndex = 14
        '
        'L60GPATB
        '
        Me.L60GPATB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "L60GPA", True))
        Me.L60GPATB.Location = New System.Drawing.Point(129, 76)
        Me.L60GPATB.Name = "L60GPATB"
        Me.L60GPATB.Size = New System.Drawing.Size(89, 20)
        Me.L60GPATB.TabIndex = 7
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(239, 83)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(42, 13)
        Me.Label18.TabIndex = 13
        Me.Label18.Text = "VPlusQ"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(239, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(121, 13)
        Me.Label19.TabIndex = 9
        Me.Label19.Text = "Years of work experince"
        '
        'AppCompTB
        '
        Me.AppCompTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "ApplicationComplete", True))
        Me.AppCompTB.Location = New System.Drawing.Point(367, 53)
        Me.AppCompTB.Name = "AppCompTB"
        Me.AppCompTB.Size = New System.Drawing.Size(65, 20)
        Me.AppCompTB.TabIndex = 12
        '
        'WorkXPTB
        '
        Me.WorkXPTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "YearsOfWorkXP", True))
        Me.WorkXPTB.Location = New System.Drawing.Point(367, 23)
        Me.WorkXPTB.Name = "WorkXPTB"
        Me.WorkXPTB.Size = New System.Drawing.Size(65, 20)
        Me.WorkXPTB.TabIndex = 10
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(239, 56)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(106, 13)
        Me.Label20.TabIndex = 11
        Me.Label20.Text = "Application Complete"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.PhoneTB)
        Me.GroupBox5.Controls.Add(Me.CountryTB)
        Me.GroupBox5.Controls.Add(Me.ZIPTB)
        Me.GroupBox5.Controls.Add(Me.StateTB)
        Me.GroupBox5.Controls.Add(Me.CityTB)
        Me.GroupBox5.Controls.Add(Me.AddressTB)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.Label9)
        Me.GroupBox5.Controls.Add(Me.Label8)
        Me.GroupBox5.Location = New System.Drawing.Point(7, 280)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(493, 101)
        Me.GroupBox5.TabIndex = 27
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Address"
        '
        'PhoneTB
        '
        Me.PhoneTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "PrimaryContactNum", True))
        Me.PhoneTB.Location = New System.Drawing.Point(304, 70)
        Me.PhoneTB.Name = "PhoneTB"
        Me.PhoneTB.Size = New System.Drawing.Size(153, 20)
        Me.PhoneTB.TabIndex = 22
        '
        'CountryTB
        '
        Me.CountryTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Country", True))
        Me.CountryTB.Location = New System.Drawing.Point(304, 41)
        Me.CountryTB.Name = "CountryTB"
        Me.CountryTB.Size = New System.Drawing.Size(153, 20)
        Me.CountryTB.TabIndex = 21
        '
        'ZIPTB
        '
        Me.ZIPTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Zip", True))
        Me.ZIPTB.Location = New System.Drawing.Point(304, 13)
        Me.ZIPTB.Name = "ZIPTB"
        Me.ZIPTB.Size = New System.Drawing.Size(153, 20)
        Me.ZIPTB.TabIndex = 20
        '
        'StateTB
        '
        Me.StateTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "State", True))
        Me.StateTB.Location = New System.Drawing.Point(65, 67)
        Me.StateTB.Name = "StateTB"
        Me.StateTB.Size = New System.Drawing.Size(153, 20)
        Me.StateTB.TabIndex = 19
        '
        'CityTB
        '
        Me.CityTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "City", True))
        Me.CityTB.Location = New System.Drawing.Point(65, 41)
        Me.CityTB.Name = "CityTB"
        Me.CityTB.Size = New System.Drawing.Size(153, 20)
        Me.CityTB.TabIndex = 18
        '
        'AddressTB
        '
        Me.AddressTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Street", True))
        Me.AddressTB.Location = New System.Drawing.Point(65, 16)
        Me.AddressTB.Name = "AddressTB"
        Me.AddressTB.Size = New System.Drawing.Size(153, 20)
        Me.AddressTB.TabIndex = 17
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(255, 74)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 13)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Phone "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(253, 45)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(43, 13)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Country"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(255, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(24, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "ZIP"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 70)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "State"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(8, 45)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(27, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "City "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Street"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.LastNameTB)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.TextBox1)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.FirstNameTB)
        Me.GroupBox4.Controls.Add(Me.DOBTB)
        Me.GroupBox4.Controls.Add(Me.MiddleNameTB)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.SSNTB)
        Me.GroupBox4.Controls.Add(Me.StudentIDTB)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Location = New System.Drawing.Point(7, 28)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(493, 130)
        Me.GroupBox4.TabIndex = 26
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Student Information"
        '
        'LastNameTB
        '
        Me.LastNameTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "LastName", True))
        Me.LastNameTB.Location = New System.Drawing.Point(65, 19)
        Me.LastNameTB.Name = "LastNameTB"
        Me.LastNameTB.Size = New System.Drawing.Size(153, 20)
        Me.LastNameTB.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "First"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(27, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Last"
        '
        'TextBox1
        '
        Me.TextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Email", True))
        Me.TextBox1.Location = New System.Drawing.Point(65, 102)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(153, 20)
        Me.TextBox1.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Middle"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 106)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Email "
        '
        'FirstNameTB
        '
        Me.FirstNameTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "FirstName", True))
        Me.FirstNameTB.Location = New System.Drawing.Point(65, 49)
        Me.FirstNameTB.Name = "FirstNameTB"
        Me.FirstNameTB.Size = New System.Drawing.Size(153, 20)
        Me.FirstNameTB.TabIndex = 5
        '
        'DOBTB
        '
        Me.DOBTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "DOB", True))
        Me.DOBTB.Location = New System.Drawing.Point(303, 80)
        Me.DOBTB.Name = "DOBTB"
        Me.DOBTB.Size = New System.Drawing.Size(105, 20)
        Me.DOBTB.TabIndex = 14
        '
        'MiddleNameTB
        '
        Me.MiddleNameTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "MiddleInitial", True))
        Me.MiddleNameTB.Location = New System.Drawing.Point(65, 76)
        Me.MiddleNameTB.Name = "MiddleNameTB"
        Me.MiddleNameTB.Size = New System.Drawing.Size(153, 20)
        Me.MiddleNameTB.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(239, 83)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(30, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "DOB"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(239, 26)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Student ID"
        '
        'SSNTB
        '
        Me.SSNTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "SSN", True))
        Me.SSNTB.Location = New System.Drawing.Point(303, 53)
        Me.SSNTB.Name = "SSNTB"
        Me.SSNTB.Size = New System.Drawing.Size(153, 20)
        Me.SSNTB.TabIndex = 12
        '
        'StudentIDTB
        '
        Me.StudentIDTB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "StudentID", True))
        Me.StudentIDTB.Location = New System.Drawing.Point(303, 23)
        Me.StudentIDTB.Name = "StudentIDTB"
        Me.StudentIDTB.Size = New System.Drawing.Size(153, 20)
        Me.StudentIDTB.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(239, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "SSN"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TextBox2)
        Me.GroupBox3.Location = New System.Drawing.Point(270, 165)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(230, 46)
        Me.GroupBox3.TabIndex = 25
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Ethnicity"
        '
        'TextBox2
        '
        Me.TextBox2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Ethnicity", True))
        Me.TextBox2.Location = New System.Drawing.Point(40, 16)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(153, 20)
        Me.TextBox2.TabIndex = 18
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.GenderTExtBox)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 165)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(219, 40)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Gender"
        '
        'GenderTExtBox
        '
        Me.GenderTExtBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Gender", True))
        Me.GenderTExtBox.Location = New System.Drawing.Point(66, 14)
        Me.GenderTExtBox.Name = "GenderTExtBox"
        Me.GenderTExtBox.Size = New System.Drawing.Size(147, 20)
        Me.GenderTExtBox.TabIndex = 17
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CitizenTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 211)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(219, 49)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Citizenship"
        '
        'CitizenTextBox
        '
        Me.CitizenTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentInfoBindingSource, "Citizenship", True))
        Me.CitizenTextBox.Location = New System.Drawing.Point(66, 19)
        Me.CitizenTextBox.Name = "CitizenTextBox"
        Me.CitizenTextBox.Size = New System.Drawing.Size(147, 20)
        Me.CitizenTextBox.TabIndex = 18
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(1, 72)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1055, 438)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1047, 412)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Credentials & Documents"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1047, 412)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Student Status"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'StudentInfoTableAdapter
        '
        Me.StudentInfoTableAdapter.ClearBeforeFill = True
        '
        'StudentRecords
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1106, 525)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "StudentRecords"
        Me.Text = "StudentRecords"
        Me.TabPage1.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentInfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents PhoneTB As System.Windows.Forms.TextBox
    Friend WithEvents CountryTB As System.Windows.Forms.TextBox
    Friend WithEvents ZIPTB As System.Windows.Forms.TextBox
    Friend WithEvents StateTB As System.Windows.Forms.TextBox
    Friend WithEvents CityTB As System.Windows.Forms.TextBox
    Friend WithEvents AddressTB As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents LastNameTB As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents FirstNameTB As System.Windows.Forms.TextBox
    Friend WithEvents DOBTB As System.Windows.Forms.TextBox
    Friend WithEvents MiddleNameTB As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents SSNTB As System.Windows.Forms.TextBox
    Friend WithEvents StudentIDTB As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GenderTExtBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CitizenTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents MajorTB As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GMATTB As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents CGPATB As System.Windows.Forms.TextBox
    Friend WithEvents VplusQTB As System.Windows.Forms.TextBox
    Friend WithEvents L60GPATB As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents AppCompTB As System.Windows.Forms.TextBox
    Friend WithEvents WorkXPTB As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents NewSearch As System.Windows.Forms.Button
    Friend WithEvents SearchButton As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents ExitButton1 As System.Windows.Forms.Button
    Friend WithEvents DataSet1 As MAINTENANCE_PROJECT.DataSet1
    Friend WithEvents StudentInfoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StudentInfoTableAdapter As MAINTENANCE_PROJECT.DataSet1TableAdapters.StudentInfoTableAdapter
    Friend WithEvents StudentIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MiddleInitialDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SSNDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DOBDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EthnicityDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GenderDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CitizenshipDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StreetDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ZipDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CountryDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PrimaryContactNumDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MajorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CumulativeGPADataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents L60GPADataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GMATDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GREDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EssayDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RecommendationLetterDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents YearsOfWorkXPDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ApplicationCompleteDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents VplusQDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
