﻿Imports System.Data
Imports System.Data.OleDb
Public Class StudentRecords
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()
    'Variables for Datagridview
    Dim ds As New DataSet
    Dim OledbAdapter As OleDbDataAdapter

    Dim con As New OleDbConnection()
    Private Sub ExitButton1_Click(sender As Object, e As EventArgs) Handles ExitButton1.Click
        Me.Close()
    End Sub

    Private Sub StudentRecords_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.StudentInfo' table. You can move, or remove it, as needed.
        Me.StudentInfoTableAdapter.Fill(Me.DataSet1.StudentInfo)

    End Sub
End Class